import React from "react";
import { NavLink } from "react-router-dom";
import { useHistory } from "react-router-dom";
import classes from "./Navbar.module.css";
function Navbar() {
  const history = useHistory();
  return (
    <header className={classes.header}>
      <div className={classes.logo}>Eye Testing</div>
      <nav className={classes.nav}>
        <ul>
          <li>
            <NavLink to="/rules">Read Rules</NavLink>
          </li>
          <li>
            <NavLink to="/confirm">Take Test</NavLink>
          </li>
          <li>
            <NavLink to="/viewres">Past Results</NavLink>
          </li>
        </ul>
        {/* <button onClick={rule}>Read Rules</button> */}
      </nav>
    </header>
  );
}

export default Navbar;
