import React from 'react';
import { useHistory } from "react-router-dom";
import "../index.css";
function Rule() {
  const history = useHistory();
  const home = () => {
    history.push("/")
  }
  return (
    <div className="App">
    <button className="btn" onClick={home}>Go back Home</button>
    </div>
  );
}
export default Rule;