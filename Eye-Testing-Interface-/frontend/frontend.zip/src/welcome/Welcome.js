import React from "react";
function Welcome() {
  return(
    <h1>Welcome to copy Page</h1>
  );
}

export default Welcome;
