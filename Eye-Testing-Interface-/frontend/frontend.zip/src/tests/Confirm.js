import React from "react";
import { useHistory } from "react-router-dom";
function Confirm() {
  const history = useHistory();
  const test1 = () => {
    history.push("/test1");
  };
  const rules = () => {
    history.push("/rules");
  };
  return (
    <div>
      <h1>Have you read the rules?</h1>
      <button  className="btn" onClick={test1}>Yes</button>
      <button  className="btn" onClick={rules}>No</button>
    </div>
  );
}

export default Confirm;
