import { useState } from "react";
import { useHistory } from "react-router-dom";
import "../index.css";
function Test6() {
  const [ip, setIp] = useState("");
  const [text, setText] = useState(Math.floor(Math.random() * 90000) + 10000);
  const [id, setId] = useState("false");
  const [showip, setShowip] = useState("true");
  const history = useHistory();
  const test7 = () => {
    history.push("/test7");
  };
  const result = () => {
    history.push("/result6");
  };
  const home = () => {
    history.push("/");
  };
  return (
    <div className="App">
      {showip && (
        <div>
          <div className="control">
            <h6>{text}</h6>
            <input
              type="text"
              value={ip}
              onChange={(e) => setIp(e.target.value)}
            />
          </div>

          <button
            type="submit"
            className="btn"
            onClick={(e) => {
              setId(true);
              setShowip(false);
            }}
          >
            Submit
          </button>
        </div>
      )}
      {id === true ? (
        <div>
          {ip == text ? (
            <button className="btn" onClick={test7}>
              Proceed to test 7?
            </button>
          ) : (
            <div>
              <h1>Test failed</h1>
              <button className="btn" onClick={result}>
                View Result?
              </button>
            </div>
          )}
        </div>
      ) : (
        <div>
          <h1>Enter the Numbers Shown Above</h1>
          <button className="btn" onClick={home}>
            End test
          </button>
        </div>
      )}
    </div>
  );
}
export default Test6;
