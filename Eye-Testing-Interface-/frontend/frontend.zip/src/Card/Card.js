import React from "react";
import "./Card.css";
function Card({ vision, spherical, astigmatic, remark }) {
  return (
    <div className="card">
      <div className="container">
        <h3>{vision}</h3>
        <h3>{spherical}</h3>
        <h3>{astigmatic}</h3>
        <h3>{remark}</h3>
      </div>
    </div>
  );
}
export default Card;
