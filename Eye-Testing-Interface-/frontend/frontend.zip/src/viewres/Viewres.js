import React from "react";
import { useEffect, useState } from "react";
import axios from "axios";
import "../Card/Card";
import "../index.css";
import "./Viewres.css";
import Card from "../Card/Card";
function Viewres() {
  const [res, setRes] = useState([]);
  useEffect(() => {
    const getRes = async () => {
      try {
        const allRes = await axios.get("http://localhost:8800/testres");
        setRes(allRes.data);
        console.log("done");
      } catch (err) {
        console.log("problem");
      }
    };
    getRes();
  }, []);
  return (
    <div>
      <h1>Previous Results</h1>
      {res.map((r) => (
        <Card
          vision={r.vision}
          spherical={r.spherical}
          astigmatic={r.astigmatic}
          remark={r.remark}
        />
      ))}
    </div>
  );
}
export default Viewres;
