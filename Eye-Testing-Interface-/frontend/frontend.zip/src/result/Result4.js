import React, { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";
import "../index.css";
function Result4() {
  const history = useHistory();
  const home = () => {
    history.push("/");
  };
  const [result, setRes] = useState([]);
  const [saved, setSave] = useState(false);
  useEffect(() => {
    const getRes = async () => {
      try {
        const allRes = await axios.get("http://localhost:8800/testres");
        setRes(allRes.data);
        console.log("done");
      } catch (err) {
        console.log("problem");
      }
    };
    getRes();
  }, []);
  const handleSubmit = async (e) => {
    e.preventDefault();
    const newRes = {
      vision: "Vision: 6/18",
      spherical: "Approximate Spherical Refractive Error: 1.00",
      astigmatic: "Approximate Astigmatic Refractive Error: 2.00",
      remark: "Please Consult a doctor",
    };
    try {
      const res = await axios.post("http://localhost:8800/testres", newRes);
      setRes([...result, res.data]);
      setSave(true);
    } catch (err) {
      console.log("problem");
    }
  };
  return (
    <div>
      <h1>Here is your result: </h1>
      <h1>Vision: 6/18</h1>
      <h1>Approximate Spherical Refractive Error: 1.00</h1>
      <h1>Approximate Astigmatic Refractive Error: 2.00</h1>
      <h1>Please Consult a Doctor</h1>
      {!saved && (
        <button className="btn" onClick={handleSubmit}>
          Save Result?
        </button>
      )}
      <button className="btn" onClick={home}>
        Go home?
      </button>
      {saved && <h2>Result Saved Successfully</h2>}
    </div>
  );
}

export default Result4;
